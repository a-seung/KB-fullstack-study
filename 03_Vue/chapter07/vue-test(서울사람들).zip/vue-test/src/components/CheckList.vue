<template>
  <div class="checklist">
    <h2>오늘 해야할 일 3개</h2>
    <h2>오늘 완료한 일 1개</h2>
  </div>
</template>

<script>
export default {
  name: 'CheckList',
};
</script>

<style lang="scss" scoped></style>
